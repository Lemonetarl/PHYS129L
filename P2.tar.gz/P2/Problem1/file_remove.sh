#! /bin/bash

echo "Please enter the directory you wish the files to be deleted"
read direc

find $direc -maxdepth 1 -type f -name "*.bin" | rm 

done
