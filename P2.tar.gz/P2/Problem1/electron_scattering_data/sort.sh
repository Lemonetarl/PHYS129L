#!/bin/bash

odd_directory='/home/yibowang/Desktop/P2/Problem1/electron_scattering_data/odd'
even_directory="/home/yibowang/Desktop/P2/Problem1/electron_scattering_data/even"

for ((i=0; i<500; i+=1)) do
	if [ $((i % 2)) == 1 ]; then
	mv "electron_scattering_2023-10-04_sample_index_$i.bin" $odd_directory
	else
	mv "electron_scattering_2023-10-04_sample_index_$i.bin" $even_directory
	fi

done
