#!/bin/bash

read -p "Enter a decimal number (0 to 99999): " decimal

if ! [[ $decimal =~ ^[0-9]+$ ]]; then
    echo "Invalid input. Please enter a valid decimal number."

fi

if ((decimal < 0 )) || ((decimal > 100000)); then
    echo "Decimal number must be between 0 and 100000."
    exit 1
fi

decimal_to_binary() {
    local num="$1"
    binary=""
    while ((num > 0)); do
        remainder=$((num % 2))
        binary="${remainder}${binary}"
        num=$((num / 2))
    done
    echo "$binary"
}


decimal_to_hexadecimal() {
    local num="$1"
    hexadecimal=""
    while ((num > 0)); do
        remainder=$((num % 16))
        case $remainder in
            10) hexadecimal="A${hexadecimal}" ;;
            11) hexadecimal="B${hexadecimal}" ;;
            12) hexadecimal="C${hexadecimal}" ;;
            13) hexadecimal="D${hexadecimal}" ;;
            14) hexadecimal="E${hexadecimal}" ;;
            15) hexadecimal="F${hexadecimal}" ;;
            *) hexadecimal="${remainder}${hexadecimal}" ;;
        esac
        num=$((num / 16))
    done
    echo "$hexadecimal"
}

binary_result=$(decimal_to_binary "$decimal")
hexadecimal_result=$(decimal_to_hexadecimal "$decimal")


echo "Decimal: $decimal"
echo "Binary: $binary_result"
echo "Hexadecimal: $hexadecimal_result"
